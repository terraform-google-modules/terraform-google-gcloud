This library has been merged into [Abseil Python Common
Libraries](https://github.com/abseil/abseil-py).

This repository is not maintained and will not be updated. Please use
[Abseil](https://github.com/abseil/abseil-py) instead.
