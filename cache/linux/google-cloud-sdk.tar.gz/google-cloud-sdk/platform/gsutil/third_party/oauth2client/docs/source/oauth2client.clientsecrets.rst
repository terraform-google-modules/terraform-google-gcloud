oauth2client\.clientsecrets module
==================================

.. automodule:: oauth2client.clientsecrets
    :members:
    :undoc-members:
    :show-inheritance:
